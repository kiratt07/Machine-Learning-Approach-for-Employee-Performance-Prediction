from flask import Flask, render_template, request
import pickle
import numpy as np

# Create Flask app
app = Flask(__name__)

# Load your trained model
model = pickle.load(open('model.pkl', 'rb'))

# Home page
@app.route('/')
def home():
    print("Home page loaded")
    return render_template('home.html')

# About page
@app.route('/about')
def about():
    print("about page loaded")
    return render_template('about.html')

# Predict form page
@app.route('/predict')
def predict():
    print("predict page loaded")
    return render_template('predict.html')

# Submit and get prediction
@app.route('/submit', methods=['POST'])
def submit():
    print("submit page loaded")
    try:
        # Get data from form
        features = [float(x) for x in request.form.values()]
        final_input = np.array([features])
        prediction = model.predict(final_input)[0]
        return render_template('submit.html', prediction_text=f"Predicted Productivity Score: {round(prediction, 2)}")
    except Exception as e:
        return render_template('submit.html', prediction_text=f"Error: {str(e)}")

# Run the app
if __name__ == '__main__':
    print("Starting Flask server...", flush=True)
    app.run(debug=True)
